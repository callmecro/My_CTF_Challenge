<?php return array (
  'DB_TYPE' => 'mysqli',
  'DB_HOST' => 'localhost',
  'DB_PORT' => '3306',
  'DB_USER' => 'root',
  'DB_PWD' => 'root',
  'DB_NAME' => 'awd2',
  'DB_PREFIX' => 'awd2_',
  'DB_CHARSET' => 'utf8',
);?>
