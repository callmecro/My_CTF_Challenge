<?php
/**

 *
 * 
 * 
 * 
 * 
 */
namespace Mobile\Controller;

class TagController extends MobileCommonController {

	public function shows() {

		A('Home/Tag')->shows(); //404

	}

}
