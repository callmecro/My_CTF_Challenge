<?php
/**

 *
 * 
 * 
 * 
 * 
 */
namespace Mobile\Controller;

class AbcController extends MobileCommonController {
	//shows
	public function shows() {

		A('Home/Abc')->shows();

	}
}
