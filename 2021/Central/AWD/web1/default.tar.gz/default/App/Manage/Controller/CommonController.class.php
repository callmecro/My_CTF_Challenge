<?php
/**

 *
 * 公共验证控制器CommonController
 * 
 * 
 * 
 * 
 */

namespace Manage\Controller;

use Think\Controller;

class CommonController extends Controller {
	//模板参数-页面标题
	protected $meta_title = '后台';

	//用户id
	protected $uid = 0;

	protected $cs_key = '';
	protected $cs_val = '';

	//_initialize自动运行方法，在每个方法前，系统会首先运动这个方法
	public function _initialize() {
		$this->uid    = session(C('USER_AUTH_KEY'));
		$this->cs_key = get_sys_xcp();
		$this->cs_val = get_sys_xcp(1);


		C(get_cfg_value()); //添加配置
		$adminFlag  = session(C('ADMIN_AUTH_KEY'));
		$authOnFlag = C('AUTH_CONFIG.AUTH_ON'); //权限开启

		$noAuth = in_array(CONTROLLER_NAME, explode(',', C('NOT_AUTH_MODULE'))) || in_array(ACTION_NAME, explode(',', C('NOT_AUTH_ACTION')));

		//是否开启验证 且 需要验证控制器或方法
        if (!$noAuth) {
            chk_sys();
        }

        if (!function_exists('chk_sys')) {
			exit();
		}

		$this->assign('uid', $this->uid);
		$this->assign('cms_name', $this->cs_key);
		$this->assign('cms_url', $this->cs_val);
		$this->setAssign();

	}

	//设置公共模板变量
	public function setAssign() {
		$this->assign('meta_title', $this->meta_title);
	}

	/**
	 * 公共免权限检测--即只要登录，不需要权限的规则
	 * @param  string  $rule 检测的规则
	 * @return boolean       true:免权限
	 */
	final protected function checkCommonRule($rule) {
		return true;

    }

    /**
     * 权限检测
     * @param  string  $rule 检测的规则
     * @param  integer $type 只验证type字段值,[1,2, array('in','1,2')]
     * @param  string  $mode check模式,url,and
     * @return boolean        [description]
     */
    final protected function checkRule($rule, $type = 1, $mode = 'url') {
		return true;
	}
	/**
	 * 检测是否是需要动态判断的权限
	 * @return boolean|null
	 *      返回true则表示当前访问有权限
	 *      返回false则表示当前访问无权限
	 *      返回null，则表示权限不明
	 */
	protected function checkDynamic() {
        return true;
	}

}
