<?php
return array(
	'XYHCMS_VER'  => '3.5',
	'XYHCMS_TIME' => '20171128',
);
