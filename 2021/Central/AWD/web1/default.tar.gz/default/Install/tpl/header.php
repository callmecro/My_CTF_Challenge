<?php if (!defined('XYHCMS_INSTALL')) {
	exit('Access Denied!');
}
?>
<div class="xyh-header">
	<div class="logo">XYHCMS</div>
	<div class="version">V3.5</div>
</div>