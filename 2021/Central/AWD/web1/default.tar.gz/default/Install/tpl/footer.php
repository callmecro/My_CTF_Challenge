
<div class="xyh-footer">
	Copyright © 2014 - 2018 <strong>XYHCMS.COM</strong> All Right Reserved
</div>
