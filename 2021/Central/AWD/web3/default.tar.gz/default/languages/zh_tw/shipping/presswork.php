<?php



$_LANG['presswork']          = '郵政掛號印刷品';
$_LANG['presswork_desc']     = '郵政掛號印刷品的描述內容。';
?>