<?php



global $_LANG;

$_LANG['cod']      = '貨到付款';
$_LANG['cod_desc'] = '開通城市：×××' . chr(13) . '貨到付款區域：×××';

?>