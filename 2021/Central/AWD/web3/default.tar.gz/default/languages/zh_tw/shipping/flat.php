<?php



$_LANG['flat']          = '市內快遞';
$_LANG['flat_desc']     = '固定運費的配送方式內容';
$_LANG['base_fee']      = '基本費用：';
$_LANG['item_fee']      = '單件商品費用：';
?>