<?php





$_LANG['sms_resource_here'] = '短信平台';

?>