<?php



global $_LANG;

$_LANG['balance']      = '餘額支付';
$_LANG['balance_desc'] = '使用帳戶餘額支付。只有會員才能使用，通過設置信用額度，可以透支。';

?>