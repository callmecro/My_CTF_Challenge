<?php



$_LANG['cac']          = '上門取貨';
$_LANG['cac_desc']     = '買家自己到商家指定地點取貨';
?>