<?php



$_LANG['goods_name'] = '商品名稱';
$_LANG['goods_last_update'] = '最新更新日期';
$_LANG['attention_addtolist'] = '插入發送隊列';
$_LANG['attention_ckaddtolist'] = '確定給關注此商品的用戶發送商品最新信息?此操作會將此商品的最新信息發送給關注此商品的用戶';
$_LANG['pri'][0] = '普通';
$_LANG['pri'][1] = '高';
$_LANG['goods_edit'] = '編輯商品';
$_LANG['finish_list'] = '已經插入 %s 條記錄,請稍後~';
$_LANG['finishing'] = '正在生成請稍後';
$_LANG['edit_ok'] = '操作成功！';
$_LANG['batch_note'] = '將此日期後更新的商品全部插入發送隊列：';
?>