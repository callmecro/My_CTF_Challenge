<?php



$_LANG['fpd']          = '運費到付';
$_LANG['fpd_desc']     = '所購商品到達即付運費';
?>