<?php



global $_LANG;

$_LANG['yunqi'] = '雲起收銀';
$_LANG['yunqi_desc'] = '雲起收銀 是國內先進的網上支付平臺。';
$_LANG['pay_button'] = '立即支付';

