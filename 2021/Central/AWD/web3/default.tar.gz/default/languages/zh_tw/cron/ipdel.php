<?php



global $_LANG;

$_LANG['ipdel']            = '瀏覽日誌刪除';
$_LANG['ipdel_desc']       = '刪除瀏覽日誌';
$_LANG['ipdel_day']   = '刪除幾天前瀏覽日誌';
$_LANG['ipdel_day_range']['7'] = '7天';
$_LANG['ipdel_day_range']['15'] = '15天';
$_LANG['ipdel_day_range']['30'] = '30天';
$_LANG['ipdel_day_range']['90'] = '90天';
$_LANG['ipdel_day_range']['180'] = '180天';
$_LANG['ipdel_day_range']['240'] = '240天';
$_LANG['ipdel_day_range']['360'] = '360天';
?>