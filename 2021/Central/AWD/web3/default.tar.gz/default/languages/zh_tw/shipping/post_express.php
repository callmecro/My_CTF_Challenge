<?php



$_LANG['post_express']          = '郵政快遞包裹';
$_LANG['post_express_desc']     = '郵政快遞包裹的描述內容。';
$_LANG['base_fee']              = '1000克以內費用：';
$_LANG['item_fee']              = '單件商品費用：';
$_LANG['step_fee']             = '5000克以內續重每500克費用：';
$_LANG['step_fee1']             = '5001克以上續重500克費用：';
?>