<?php



$_LANG['shopex48_desc']     = 'shopex Single V4.8（支持到4.8.4版本）';
$_LANG['step_file']         = '正在複製文件...';
$_LANG['step_cat']          = '正在轉換商品分類...';
$_LANG['step_brand']        = '正在轉換商品品牌...';
$_LANG['step_goods']        = '正在轉換商品...';
$_LANG['step_users']        = '正在轉換會員...';
$_LANG['step_article']      = '正在轉換文章...';
$_LANG['step_order']        = '正在轉換訂單...';
$_LANG['step_config']       = '正在轉換商店設置...';

?>