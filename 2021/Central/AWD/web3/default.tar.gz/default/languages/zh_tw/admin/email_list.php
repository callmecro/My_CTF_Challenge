<?php


$_LANG['email_val'] = '郵件地址';
$_LANG['stat']['name'] = '狀態';
$_LANG['stat'][0] = '未確認';
$_LANG['stat'][1] = '已確認';
$_LANG['stat'][2] = '已退訂';
$_LANG['export'] = '導出列表';
$_LANG['id'] = '編號';
$_LANG['button_remove'] = '刪除';
$_LANG['button_unremove'] = '確認';
$_LANG['button_exit'] = '退訂';
$_LANG['no_select_email'] = '沒有選定的Email';
$_LANG['batch_remove_succeed'] = '已成功刪除 %d 個E-mail地址';
$_LANG['batch_unremove_succeed'] = '已成功確認 %d 個E-mail地址';
$_LANG['batch_exit_succeed'] = '已成功退訂 %d 個E-mail地址';
$_LANG['back_list'] = '返回郵件列表';
?>