<?php



global $_LANG;

$_LANG['auto_manage']            = '自動處理';
$_LANG['auto_manage_desc']       = '自動處理商品的上架下架,和文章的發佈取消';
$_LANG['auto_manage_count']   = '每次處理記錄個數';
$_LANG['auto_manage_count_range']['5'] = '5';
$_LANG['auto_manage_count_range']['10'] = '10';
$_LANG['auto_manage_count_range']['20'] = '20';
$_LANG['auto_manage_count_range']['50'] = '50';

?>