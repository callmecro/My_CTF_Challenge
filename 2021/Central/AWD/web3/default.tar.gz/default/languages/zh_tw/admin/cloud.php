<?php





$_LANG['cloud_no_priv'] = '您的權限不足,無法關閉';


?>
