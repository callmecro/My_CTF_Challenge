<?php



$_LANG['city_express']        = '城際快遞';
$_LANG['city_express_desc']   = '配送的運費是固定的';
$_LANG['base_fee']      = '基本費用：';
$_LANG['item_fee']      = '單件商品費用：';
?>
