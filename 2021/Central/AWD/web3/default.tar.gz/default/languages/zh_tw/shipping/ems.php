<?php



$_LANG['ems']                   = 'EMS 國內郵政特快專遞';
$_LANG['ems_express_desc']      = 'EMS 國內郵政特快專遞描述內容';
$_LANG['item_fee']              = '單件商品費用：';
$_LANG['base_fee']              = '500克以內費用：';
$_LANG['step_fee']              = '續重每500克或其零數：';
?>