<?php



$_LANG['tab_general'] = '綜合訪問量';
$_LANG['tab_area'] = '地區分佈';
$_LANG['tab_from'] = '來源網站';

$_LANG['general_stats'] = '綜合訪問量統計';
$_LANG['area_stats'] = '地區分佈統計';
$_LANG['from_stats'] = '來源網站統計';

$_LANG['url'] = '地址';
$_LANG['area'] = '地區';
$_LANG['input_url'] = '直接輸入地址';
$_LANG['date'] = '日期';
$_LANG['access_count'] = '訪問量';
$_LANG['access_query'] = '查詢';
$_LANG['compare_query'] = '對比查詢';

$_LANG['start_date'] = '開始日期';
$_LANG['end_date'] = '結束日期';

$_LANG['down_flow_stats'] = '流量分析報表下載';
$_LANG['flow_statistics'] = '流量分析報表';

?>