<?php



$_LANG['post_mail']          = '郵局平郵';
$_LANG['post_mail_desc']     = '郵局平郵的描述內容。';
$_LANG['pack_fee']           = '包裝費用：';
$_LANG['base_fee']          = '1000克以內費用：';
$_LANG['item_fee']          = '單件商品費用：';
$_LANG['step_fee']          = '5000克以內續重每1000克費用：';
$_LANG['step_fee1']          = '5001克以上續重1000克費用：';

?>