<?php



global $_LANG;

$_LANG['ipdel']            = 'View log delete';
$_LANG['ipdel_desc']       = 'Delete Browsing Log';
$_LANG['ipdel_day']   = 'Delete a few days ago View Log';
$_LANG['ipdel_day_range']['7'] = '7 Days';
$_LANG['ipdel_day_range']['15'] = '15 Days';
$_LANG['ipdel_day_range']['30'] = '30 Days';
$_LANG['ipdel_day_range']['90'] = '90 Days';
$_LANG['ipdel_day_range']['180'] = '180 Days';
$_LANG['ipdel_day_range']['240'] = '240 Days';
$_LANG['ipdel_day_range']['360'] = '360 Days';
?>