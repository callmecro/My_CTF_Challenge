<?php



$_LANG['flat']          = 'Intra-city shipping';
$_LANG['flat_desc']     = 'Payment method contents of cost is fixed ';
$_LANG['base_fee']      = 'Basic expenditure:';
?>