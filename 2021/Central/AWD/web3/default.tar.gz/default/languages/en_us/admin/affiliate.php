<?php



$_LANG['on'] = 'Open';
$_LANG['off'] = 'Close';

$_LANG['separate_by'][0] = 'Recommend register is divided into';
$_LANG['separate_by'][1] = 'Recommend orders into';

$_LANG['expire'] = 'Recommend limitation:';
$_LANG['level_point_all'] = 'The total percentage of points is divided into:';
$_LANG['level_money_all'] = 'The total percentage of the cash is divided into:';
$_LANG['level_register_all'] = 'Registration is divided into a number of points:';
$_LANG['level_register_up'] = 'Grade points are divided into the ceiling:';
$_LANG['level_point'] = 'Divided into percentage points';
$_LANG['level_money'] = 'The percentage of cash into';
$_LANG['edit_ok'] = 'Successful operation';
$_LANG['level_error'] = 'Set up to level 5!';
$_LANG['levels'] = 'Recommend people level';
$_LANG['js_languages']['lang_removeconfirm'] = 'Are you sure you want to delete this grade it?';
$_LANG['js_languages']['save'] = 'Save';
$_LANG['js_languages']['cancel'] = 'Cancel';

$_LANG['unit']['hour'] = 'Hours';
$_LANG['unit']['day'] = 'Days';
$_LANG['unit']['week'] = 'Week';

$_LANG['addrow'] = 'Increase';

$_LANG['all_null'] = 'Can not all space';

$_LANG['help_expire'] = 'Visitors click on a web site people recommend, in this time period register, the next single, that is what the people recommend the introduction.';
$_LANG['help_lpa'] = 'Orders integral part of this percentage as divided by Integral.';
$_LANG['help_lma'] = 'The amount of orders as part of this percentage divided by the amount.';
$_LANG['help_lra'] = 'Introduction of Member Registration, references available rating points.';
$_LANG['help_lru'] = 'Integral to this level of the ceiling is no longer reward points introduce Register.';
?>