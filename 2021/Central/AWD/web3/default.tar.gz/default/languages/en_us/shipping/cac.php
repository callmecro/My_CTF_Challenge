<?php



$_LANG['cac']          = 'Door-to-door trade';
$_LANG['cac_desc']     = 'Purchaser get the product from place of shopkeeper appoint';
?>