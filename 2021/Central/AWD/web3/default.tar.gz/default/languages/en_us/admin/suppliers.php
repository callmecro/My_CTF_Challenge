<?php




$_LANG['add_suppliers'] = 'Add suppliers';
$_LANG['edit_suppliers'] = 'Edit suppliers';
$_LANG['suppliers_list'] = 'Suppliers list';


$_LANG['suppliers_name'] = 'Suppliers name';
$_LANG['suppliers_desc'] = 'Suppliers description';
$_LANG['suppliers_check'] = 'State';


$_LANG['label_suppliers_name'] = 'suppliers name：';
$_LANG['label_suppliers_desc'] = 'suppliers description：';
$_LANG['label_admins'] = 'admin in charge of this supplier：';
$_LANG['notice_admins'] = 'the admin marked by (*) has in charge of other suppliers';
$_LANG['suppliers_name_exist'] = 'this supplier has existed, please use another name';


$_LANG['continue_add_suppliers'] = 'continue to add suppliers';
$_LANG['back_suppliers_list'] = 'back to suppliers list';
$_LANG['add_suppliers_ok'] = 'add suppliers succesful';
$_LANG['edit_suppliers_ok'] = 'edit suppliers succesful';
$_LANG['batch_drop_no'] = 'Bulk delete failed';
$_LANG['batch_drop_ok'] = 'batched delete succesful';
$_LANG['suppliers_edit_fail'] = 'fail to edit name';
$_LANG['no_record_selected'] = 'no record selected';


$_LANG['js_languages']['no_suppliers_name'] = 'no supplier name';
?>