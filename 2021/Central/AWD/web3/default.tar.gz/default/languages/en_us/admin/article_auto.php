<?php



$_LANG['id'] = 'No.';

$_LANG['starttime'] = 'Published';
$_LANG['endtime'] = 'The abolition of time';
$_LANG['goods_name'] = 'Article name';
$_LANG['ok'] = 'Determine';
$_LANG['edit_ok'] = 'Successful operation';
$_LANG['delete'] = 'Revocation';
$_LANG['deleteck'] = 'Delete this article to determine the automatic publish // unpublish handle it? This action will not affect the article itself';
$_LANG['enable_notice'] = 'You need to system settings -> plans to open mission in order to use this feature.';
$_LANG['button_start'] = 'Batch Release';
$_LANG['button_end'] = 'Volume Unpublishing';

$_LANG['no_select_goods'] = 'No article selected';

$_LANG['batch_start_succeed'] = 'Batch successfully posted';
$_LANG['batch_end_succeed'] = 'Cancel Batch success';

$_LANG['back_list'] = 'Published article automatically return';
$_LANG['select_time'] = 'Please select the time';

?>
