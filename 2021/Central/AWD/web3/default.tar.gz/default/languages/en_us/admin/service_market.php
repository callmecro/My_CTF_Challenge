<?php





$_LANG['service_market_here'] = 'service market';

?>