<?php




$_LANG['cloud_no_priv'] = 'You  don\'t have enough permissions';

?>
