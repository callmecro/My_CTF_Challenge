<?php



global $_LANG;

$_LANG['yunqi'] = 'Yunqi cashier';
$_LANG['yunqi_desc'] = 'The cashier is from the domestic advanced online payment platform。';
$_LANG['pay_button'] = 'Immediate payment of the use of Yunqi cashier';


