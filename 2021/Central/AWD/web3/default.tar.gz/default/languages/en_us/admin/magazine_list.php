<?php



$_LANG['add_new'] = 'Add a new magazine';
$_LANG['magazine_name'] = 'Magazine name';
$_LANG['magazine_edit'] = 'edit';
$_LANG['magazine_del'] = 'delete';
$_LANG['ck_del'] = 'Determine the delete?';
$_LANG['finish_list'] = 'already inserted %s records, please wait for a moment';
$_LANG['finishing'] = 'Are generated later';
$_LANG['magazine_addtolist'] = 'Insert Send Queue';
$_LANG['magazine_ckaddtolist'] = 'Insert magazine confirmed this mass-mailing list? This action will give the existing mailing list to send this E-zine';
$_LANG['pri'][0] = 'Ordinary';
$_LANG['pri'][1] = 'High';
$_LANG['magazine_last_update'] = 'Last edited magazine';
$_LANG['magazine_last_send'] = 'Magazine of the last send time';
$_LANG['magazine_content'] = 'Magazine content (support for html)';
$_LANG['go_list'] = 'Return list';
$_LANG['edit_ok'] = 'Operation successful!';
$_LANG['email_user'] = 'E-mail subscribers';
$_LANG['user_list'] = 'All Member';

?>