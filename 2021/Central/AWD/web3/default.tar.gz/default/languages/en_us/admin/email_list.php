<?php


$_LANG['email_val'] = 'E-mail address';
$_LANG['stat']['name'] = 'State';
$_LANG['stat'][0] = 'Not confirmed';
$_LANG['stat'][1] = 'Has confirmed';
$_LANG['stat'][2] = 'Have to unsubscribe';
$_LANG['export'] = 'Export List';
$_LANG['id'] = 'No.';
$_LANG['button_remove'] = 'Remove';
$_LANG['button_unremove'] = 'Confirmed';
$_LANG['button_exit'] = 'Unsubscribe';
$_LANG['no_select_email'] = 'Email not selected';
$_LANG['batch_remove_succeed'] = 'Has been successfully deleted %d E-mail Address';
$_LANG['batch_unremove_succeed'] = 'Has been successfully confirmed %d E-mail Address';
$_LANG['batch_exit_succeed'] = 'Has been successfully unsubscribe %d E-mail Address';
$_LANG['back_list'] = 'Return mailing list';
?>