<?php





$_LANG['logistic_tracking_here'] = 'Logistic Tracking';

?>