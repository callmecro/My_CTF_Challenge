<?php



$_LANG['item'] = 'Item';
$_LANG['read'] = 'Readable';
$_LANG['write'] = 'Writable';
$_LANG['modify'] = 'Revisability';
$_LANG['dir'] = ' directory';
$_LANG['dir_subdir'] = ' directory and subdirectory.';
$_LANG['tpl_file'] = ' subdirectory and all files.';
$_LANG['detail'] = 'Details';

$_LANG['unread'] = 'Unreadable';
$_LANG['unwrite'] = 'Unwritable';
$_LANG['unmodify'] = 'Unrevisable';

$_LANG['unrename'] = 'Directory need to run rename authorization.';
?>