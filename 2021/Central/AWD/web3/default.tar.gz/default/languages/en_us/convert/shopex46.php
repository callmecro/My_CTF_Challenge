<?php


$_LANG['shopex46_desc']     = 'Shopex Single V4.6';

$_LANG['step_file']         = 'Copying files...';
$_LANG['step_cat']          = 'Converting product category...';
$_LANG['step_brand']        = 'Converting product brand...';
$_LANG['step_goods']        = 'Converting product...';
$_LANG['step_users']        = 'Converting user...';
$_LANG['step_article']      = 'Converting article...';
$_LANG['step_order']        = 'Converting product order...';
$_LANG['step_config']       = 'Converting config for shop...';
?>