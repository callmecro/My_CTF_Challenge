<?php



$_LANG['goods_name'] = 'Trade names';
$_LANG['goods_last_update'] = 'Last updated';
$_LANG['attention_addtolist'] = 'Insert Send Queue';
$_LANG['attention_ckaddtolist'] = 'The concern is determined to send the merchandise merchandise-to-date information? This merchandise would be the latest information sent to users concerned about this merchandise';
$_LANG['pri'][0] = 'Ordinary';
$_LANG['pri'][1] = 'High';
$_LANG['goods_edit'] = 'Editor merchandise';
$_LANG['finish_list'] = 'Has been inserted into %s records, please later ~';
$_LANG['finishing'] = 'Are generated later';
$_LANG['edit_ok'] = 'Operation successful!';
$_LANG['batch_note'] = 'After the date of this update all merchandise insert send queue:';
?>