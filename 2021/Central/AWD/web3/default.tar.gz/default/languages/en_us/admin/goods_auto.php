<?php


$_LANG['id'] = 'id';

$_LANG['starttime'] = 'Was added to our catalog';
$_LANG['endtime'] = 'Under the time frame';
$_LANG['select_time'] = 'Please select the time';
$_LANG['goods_name'] = 'Trade names';
$_LANG['ok'] = 'Determine';
$_LANG['edit_ok'] = 'Successful operation';
$_LANG['delete'] = 'Revocation';
$_LANG['deleteck'] = 'Delete this merchandise to determine the automatic shelves shelves deal with it? This action will not affect the product itself';
$_LANG['enable_notice'] = 'You need to system settings -> plans to open mission in order to use this feature.';
$_LANG['button_start'] = 'Volume was added to our catalog';
$_LANG['button_end'] = 'Volume under the plane';

$_LANG['no_select_goods'] = 'Not selected merchandise';

$_LANG['batch_start_succeed'] = 'Volume shelves success';
$_LANG['batch_end_succeed'] = 'Volume under the plane success';

$_LANG['back_list'] = 'Merchandise automatically back up and down plane';
?>
