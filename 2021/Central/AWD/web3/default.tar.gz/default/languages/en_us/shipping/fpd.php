<?php



$_LANG['fpd']          = 'Freight forward';
$_LANG['fpd_desc']     = 'Payment after the product arrived';
?>