<?php



$_LANG['homepage_changefreq'] = 'Home page update frequency';
$_LANG['category_changefreq'] = 'Category page update frequency';
$_LANG['content_changefreq'] = 'Content page update frequency';

$_LANG['priority']['always'] = 'Always';
$_LANG['priority']['hourly'] = 'Hourly';
$_LANG['priority']['daily'] = 'Daily';
$_LANG['priority']['weekly'] = 'Weekly';
$_LANG['priority']['monthly'] = 'Monthly';
$_LANG['priority']['yearly'] = 'Yearly';
$_LANG['priority']['never'] = 'Never';

$_LANG['generate_success'] = 'Creat sitemap to data directory. <br />Address : %s';
$_LANG['generate_failed'] = 'Creat sitemap faied, please check /data/ directory whether can be wrote.';
$_LANG['sitemaps_note'] = 'Sitemaps service for the Feed file sitemap.xml notice Google,Yahoo! and Microsoft and so on, and the Crawler website which files need to index, the last edit time, update frequency, file position , relative index priority, and this information will help them to establish range and habit of behavior. Details: <a href="http://www.sitemaps.org/" target="_blank">sitemaps.org</a>.';
?>