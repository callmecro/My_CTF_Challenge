<?php



$_LANG['city_express']        = 'Inter-city shipping';
$_LANG['city_express_desc']   = 'Cost of shipping is fixed ';
$_LANG['base_fee']      = 'Basic expenditure:';
?>
