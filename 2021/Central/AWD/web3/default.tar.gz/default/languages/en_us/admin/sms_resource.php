<?php





$_LANG['sms_resource_here'] = 'Sms resource';

?>