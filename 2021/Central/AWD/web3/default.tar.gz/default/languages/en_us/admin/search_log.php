<?php



$_LANG['keywords'] = 'Keyword';
$_LANG['date'] = 'date';
$_LANG['hits'] = 'Search Views';
$_LANG['start_date'] = 'Start Date';
$_LANG['end_date'] = 'Ending Date';
$_LANG['query'] = 'Query';

?>