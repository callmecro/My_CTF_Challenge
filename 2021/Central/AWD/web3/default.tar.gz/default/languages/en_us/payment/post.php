<?php



global $_LANG;

$_LANG['post']      = 'Remittance';
$_LANG['post_desc'] = 'Payee\'s information: Name ××× : Address ×××: Postalcode ××× .' . chr(13) .
                        'Announcements: Please note your order number in postscript at the back of cash remittance, only fill the last 6 locations.';

?>