<?php



global $_LANG;

$_LANG['auto_manage']            = 'Automatic processing';
$_LANG['auto_manage_desc']       = 'Automatic processing of the merchandise shelf shelves, and the release of the abolition of article';
$_LANG['auto_manage_count']   = 'Record the number of each treatment';
$_LANG['auto_manage_count_range']['5'] = '5';
$_LANG['auto_manage_count_range']['10'] = '10';
$_LANG['auto_manage_count_range']['20'] = '20';
$_LANG['auto_manage_count_range']['50'] = '50';

?>