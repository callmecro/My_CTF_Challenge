<?php



$_LANG['post_mail']          = 'Common mailing';
$_LANG['post_mail_desc']     = 'Common mailing\'s description';
$_LANG['pack_fee']           = 'Packing money:';
$_LANG['base_fee']          = 'Cost less than 1000g:';
$_LANG['item_fee']           = 'Single commodity costs:';
$_LANG['step_fee']          = 'Less than 5000g, cost of every 1000g:';
$_LANG['step_fee1']          = 'More than 5001g, cost of every 1000g:';

?>