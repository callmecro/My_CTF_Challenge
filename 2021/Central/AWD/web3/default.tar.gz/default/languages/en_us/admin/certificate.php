<?php




$_LANG['download_license'] = 'download license';


$_LANG['certificate_here'] = 'license certificate';



$_LANG['label_shopex'] = 'Shopex license';
$_LANG['label_shopex_id'] = 'shopex_id：';
$_LANG['label_certificate'] = 'license';
$_LANG['label_node_id'] = 'node id：';
$_LANG['label_certificate_id'] = 'current license：';
$_LANG['label_delete_certificate'] = 'delete license：';
$_LANG['label_bindrelation'] = 'Erp bindrelation';
$_LANG['label_my_version'] = 'my version';
$_LANG['apply_bindrelation'] = 'apply bindrelation';
$_LANG['accept_bindrelation'] = 'accept bindrelation';
$_LANG['yunqi_certicate'] = 'Activation system';
$_LANG['delete_certificate'] = 'delete license';


$_LANG['license_notice'] = 'ECShop certificate is the only mark to enjoy the ECShop service, it records important information such as information about your business、record of buying service、the prepaid account amounts. You need to use the function of "certificate download and backup" to backup the certificate, and keep safely. When your shop system needs to reinstall, you can use the function of "certificate download and backup" to recover the certificate backuped before in the new installed system, this new system can continue to use the important informations in the certificate.';
$_LANG['no_license_down'] = "Failure。No certificate can be downloaded temporarily！";

?>