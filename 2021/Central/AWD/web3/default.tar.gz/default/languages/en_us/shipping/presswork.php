<?php



$_LANG['presswork']          = 'Postal presswork shipping packing.';
$_LANG['presswork_desc']     = 'Postal presswork shipping packing description.。';
?>