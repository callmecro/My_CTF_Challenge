<?php



global $_LANG;

$_LANG['cod']      = 'Cash on shipping';
$_LANG['cod_desc'] = 'City of COD:×××' . chr(13) . 'Region of COD:×××';

?>