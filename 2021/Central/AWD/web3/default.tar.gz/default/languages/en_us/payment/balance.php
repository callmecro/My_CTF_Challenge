<?php



global $_LANG;

$_LANG['balance']      = 'Balance of payments';
$_LANG['balance_desc'] = 'The use of your account balance. Only members can use, by setting the line of credit can be overdrawn.';

?>