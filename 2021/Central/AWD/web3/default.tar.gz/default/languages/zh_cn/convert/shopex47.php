<?php



$_LANG['shopex47_desc']     = 'shopex Single V4.7';

$_LANG['step_file']         = '正在复制文件...';
$_LANG['step_cat']          = '正在转换商品分类...';
$_LANG['step_brand']        = '正在转换商品品牌...';
$_LANG['step_goods']        = '正在转换商品...';
$_LANG['step_users']        = '正在转换会员...';
$_LANG['step_article']      = '正在转换文章...';
$_LANG['step_order']        = '正在转换订单...';
$_LANG['step_config']       = '正在转换商店设置...';

?>