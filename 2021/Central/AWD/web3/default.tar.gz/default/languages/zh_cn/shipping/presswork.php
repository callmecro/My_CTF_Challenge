<?php



$_LANG['presswork']          = '邮政挂号印刷品';
$_LANG['presswork_desc']     = '邮政挂号印刷品的描述内容。';
?>