<?php



$_LANG['flat']          = '市内快递';
$_LANG['flat_desc']     = '固定运费的配送方式内容';
$_LANG['base_fee']      = '基本费用：';
?>