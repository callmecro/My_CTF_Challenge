<?php



global $_LANG;

$_LANG['cod']      = '货到付款';
$_LANG['cod_desc'] = '开通城市：×××' . chr(13) . '货到付款区域：×××';

?>