<?php



$_LANG['goods_name'] = '商品名称';
$_LANG['goods_last_update'] = '最新更新日期';
$_LANG['attention_addtolist'] = '插入发送队列';
$_LANG['attention_ckaddtolist'] = '确定给关注此商品的用户发送商品最新信息?此操作会将此商品的最新信息发送给关注此商品的用户';
$_LANG['pri'][0] = '普通';
$_LANG['pri'][1] = '高';
$_LANG['goods_edit'] = '编辑商品';
$_LANG['finish_list'] = '已经插入 %s 条记录,请稍后~';
$_LANG['finishing'] = '正在生成请稍后';
$_LANG['edit_ok'] = '操作成功！';
$_LANG['batch_note'] = '将此日期后更新的商品全部插入发送队列：';
?>