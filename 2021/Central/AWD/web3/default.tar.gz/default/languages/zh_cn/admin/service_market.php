<?php





$_LANG['service_market_here'] = '服务市场';

?>