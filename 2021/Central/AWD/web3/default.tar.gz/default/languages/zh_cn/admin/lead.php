<?php




$_LANG['lead_here'] = '移动版';


$_LANG['lead_open'] = '免费开通';
$_LANG['lead_into'] = '点击进入';


?>