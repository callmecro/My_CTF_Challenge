<?php



$_LANG['keywords'] = '关键字';
$_LANG['date'] = '日期';
$_LANG['hits'] = '搜索次数';
$_LANG['start_date'] = '开始日期';
$_LANG['end_date'] = '结束日期';
$_LANG['query'] = '查询';

?>