<?php



$_LANG['fpd']          = '运费到付';
$_LANG['fpd_desc']     = '所购商品到达即付运费';
?>