<?php


$_LANG['email_val'] = '邮件地址';
$_LANG['stat']['name'] = '状态';
$_LANG['stat'][0] = '未确认';
$_LANG['stat'][1] = '已确认';
$_LANG['stat'][2] = '已退订';
$_LANG['export'] = '导出列表';
$_LANG['id'] = '编号';
$_LANG['button_remove'] = '删除';
$_LANG['button_unremove'] = '确认';
$_LANG['button_exit'] = '退订';
$_LANG['no_select_email'] = '没有选定的Email';
$_LANG['batch_remove_succeed'] = '已成功删除 %d 个E-mail地址';
$_LANG['batch_unremove_succeed'] = '已成功确认 %d 个E-mail地址';
$_LANG['batch_exit_succeed'] = '已成功退订 %d 个E-mail地址';
$_LANG['back_list'] = '返回邮件列表';
?>