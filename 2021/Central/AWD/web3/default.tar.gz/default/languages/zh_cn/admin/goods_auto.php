<?php


$_LANG['id'] = '编号';

$_LANG['starttime'] = '上架时间';
$_LANG['endtime'] = '下架时间';
$_LANG['select_time'] = '请选定时间';
$_LANG['goods_name'] = '商品名称';
$_LANG['ok'] = '确定';
$_LANG['edit_ok'] = '操作成功';
$_LANG['delete'] = '撤销';
$_LANG['deleteck'] = '确定删除此商品的自动上架下架处理么?此操作不会影响商品本身';
$_LANG['enable_notice'] = '您需要到系统设置->计划任务中开启该功能后才能使用。';
$_LANG['button_start'] = '批量上架';
$_LANG['button_end'] = '批量下架';

$_LANG['no_select_goods'] = '没有选定商品';

$_LANG['batch_start_succeed'] = '批量上架成功';
$_LANG['batch_end_succeed'] = '批量下架成功';

$_LANG['back_list'] = '返回商品自动上下架';
?>
