<?php






$_LANG['cloud_no_priv'] = '您的权限不足,无法关闭';

?>