<?php



$_LANG['cac']          = '上门取货';
$_LANG['cac_desc']     = '买家自己到商家指定地点取货';
?>