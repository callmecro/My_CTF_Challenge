<?php



global $_LANG;

$_LANG['auto_manage']            = '自动处理';
$_LANG['auto_manage_desc']       = '自动处理商品的上架下架,和文章的发布取消';
$_LANG['auto_manage_count']   = '每次处理记录个数';
$_LANG['auto_manage_count_range']['5'] = '5';
$_LANG['auto_manage_count_range']['10'] = '10';
$_LANG['auto_manage_count_range']['20'] = '20';
$_LANG['auto_manage_count_range']['50'] = '50';

?>