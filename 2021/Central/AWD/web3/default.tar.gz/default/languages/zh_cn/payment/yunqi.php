<?php



global $_LANG;

$_LANG['yunqi'] = '云起收银';
$_LANG['yunqi_desc'] = '云起收银 是国内先进的网上支付平台。';
$_LANG['pay_button'] = '立即支付';

