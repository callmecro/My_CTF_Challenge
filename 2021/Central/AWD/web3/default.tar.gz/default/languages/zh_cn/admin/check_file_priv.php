<?php



$_LANG['item'] = '项目';
$_LANG['read'] = '可读权限';
$_LANG['write'] = '可写权限';
$_LANG['modify'] = '可修改权限';
$_LANG['dir'] = '目录';
$_LANG['dir_subdir'] = '目录及其子目录';
$_LANG['tpl_file'] = '下所有模板文件';
$_LANG['detail'] = '详情';

$_LANG['unread'] = '不可读';
$_LANG['unwrite'] = '不可写';
$_LANG['unmodify'] = '不可修改';

$_LANG['unrename'] = '目录需要执行rename权限';
?>