<?php


 $_LANG['id'] = '编号';

$_LANG['starttime'] = '发布时间';
$_LANG['endtime'] = '取消时间';
$_LANG['goods_name'] = '文章名称';
$_LANG['ok'] = '确定';
$_LANG['edit_ok'] = '操作成功';
$_LANG['delete'] = '撤销';
$_LANG['deleteck'] = '确定删除此文章的自动发布/取消发布处理么?此操作不会影响文章本身';
$_LANG['enable_notice'] = '您需要到系统设置->计划任务中开启该功能后才能使用。';
$_LANG['button_start'] = '批量发布';
$_LANG['button_end'] = '批量取消发布';

$_LANG['no_select_goods'] = '没有选定文章';

$_LANG['batch_start_succeed'] = '批量发布成功';
$_LANG['batch_end_succeed'] = '批量取消成功';

$_LANG['back_list'] = '返回文章自动发布';
$_LANG['select_time'] = '请选定时间';

?>
