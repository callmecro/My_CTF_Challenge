<?php



global $_LANG;

$_LANG['balance']      = '余额支付';
$_LANG['balance_desc'] = '使用帐户余额支付。只有会员才能使用，通过设置信用额度，可以透支。';

?>