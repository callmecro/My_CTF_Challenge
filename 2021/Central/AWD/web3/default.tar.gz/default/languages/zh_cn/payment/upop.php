<?php



global $_LANG;

$_LANG['upop']                       = '银联在线支付';
$_LANG['upop_desc']                  = '银联在线支付是中国银联推出的网上支付平台，支持多家发卡银行，涵盖借记卡和信用卡等，包含认证支付、快捷支付和网银支付多种方式，其中认证和快捷支付无需开通网银，仅需一张银行卡，即可享受安全、快捷的网上支付服务！';
$_LANG['upop_merAbbr']                = '商户名称';
$_LANG['upop_account']              = '商户帐号';
$_LANG['upop_security_key']            = '商户密钥';

$_LANG['upop_button']               = '立即支付';
$_LANG['upop_txn_id']               = '银联交易号';

?>
