<?php



$_LANG['post_mail']          = '邮局平邮';
$_LANG['post_mail_desc']     = '邮局平邮的描述内容。';
$_LANG['pack_fee']           = '包装费用：';
$_LANG['item_fee']              = '单件商品费用：';
$_LANG['base_fee']          = '1000克以内费用：';
$_LANG['step_fee']          = '5000克以内续重每1000克费用：';
$_LANG['step_fee1']          = '5001克以上续重1000克费用：';

?>