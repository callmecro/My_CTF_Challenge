#!/bin/sh
python -u /opt/server.py